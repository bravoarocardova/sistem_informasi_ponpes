<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title><?= $profilApp['nama_pondok'] ?></title>
<link rel="shortcut icon" href="<?= base_url() . 'img/icon/' . $profilApp['logo'] ?>" type="image/x-icon">

<!-- Bootstrap CSS -->
<link href="<?= base_url() ?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?= base_url() ?>css/home.css" rel="stylesheet">

<link rel="stylesheet" href="<?= base_url() ?>plugins/fontawesome-free/css/all.min.css">